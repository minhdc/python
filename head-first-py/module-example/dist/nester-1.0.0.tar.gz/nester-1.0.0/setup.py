from distutils.core import setup

setup(
        name        = 'nester',
        version     = '1.0.0',
        py_modules  = ['nester'],
        author      = 'extreme45nm',
        author_email= 'extreme45nm-at-shit_mail.com',
        url         = 'wordpress.busybuggy.com',
        description = 'a simple printer of nested list...',
        )
